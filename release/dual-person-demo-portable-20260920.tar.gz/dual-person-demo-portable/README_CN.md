# RK3588 双 IMX415 全局搜索 + 高速 ROI 人体检测迁移包

这是从已验证板端整理出的可迁移包，包含可直接部署的 AArch64 runtime、YOLOv5n RKNN 模型、配套动态库、支持 640×640 ROI 的 IMX415 IQ 文件、相机配置与 HDMI 显示程序，以及应用/驱动参考源码。

## 快速使用

目标板的软件镜像和 CSI3/CSI4 media 拓扑与原板一致时，在主机执行：

```sh
adb devices
./deploy-adb.sh 设备序列号
adb -s 设备序列号 shell 'cd /userdata/dual-person-demo && ./run.sh'
```

如果只连接一块板，可省略设备序列号。部署前建议先阅读：

- `docs/PORTING_GUIDE_CN.md`：依赖、ADB 部署、驱动迁移和验收步骤；
- `docs/ARCHITECTURE_AND_LIMITS_CN.md`：数据通路、实测基线、当前不足和优化路线；
- `docs/ORIGINAL_TEST_NOTES_CN.md`：原板测试记录。

## 重要限制

该包不是任意 RK3588 镜像上的即插即用应用。高速动态 ROI 依赖定制 IMX415 内核驱动；当前应用和脚本还固定使用原板的 media/video/subdev 节点。`runtime/preflight.sh` 会在启动前检查关键依赖，失败时不会继续改写相机配置。

`source/rknn-overlay/` 只保存相对于 `rknn_model_zoo` 的相关修改文件，重新编译时仍需完整的原始 model zoo、交叉编译器和 RKNN/RGA SDK。`source/driver/imx415.c` 是来源 Linux 6.1 BSP 的完整参考驱动，应通过代码审查/补丁方式合入目标 BSP，而不是直接复制到根文件系统。

## 原板性能基线

- CSI3 全局输入：3840×2160 RAW10 约 60 FPS，ISP 输出 960×540 NV12；
- CSI4 传感器 ROI：648×640 RAW10 约 110 FPS，ISP 输出 640×480 NV12；
- 无人时全局 YOLO 约 60 FPS；ROI 激活时全局约 9～10 FPS、ROI YOLO 约 96～98 FPS；
- 三核纯 ROI 吞吐约 100～106.5 FPS。

这些是原板实测参考，不代表换板后的保证值。应按迁移指南重新验收。
